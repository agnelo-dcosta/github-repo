package org.aggi.sqldata;

public class DatabaseReader {

}
